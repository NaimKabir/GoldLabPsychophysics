% Do-nothing test used in the examples for organizing tests inside packages.
%
% Steven L. Eddins
% Copyright 2010 The MathWorks, Inc.

function test_that
