function testSin
% Copyright 2013 The MathWorks, Inc.

assertElementsAlmostEqual(sin(pi), 0);
