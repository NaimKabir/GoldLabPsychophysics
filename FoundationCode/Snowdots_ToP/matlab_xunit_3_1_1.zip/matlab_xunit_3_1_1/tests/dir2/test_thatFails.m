function test_suite = test_thatFails

% Copyright 2013 The MathWorks, Inc.

initTestSuite;

function test_case
assertTrue(false);
