% test_this.m is a function-file test case.

% Copyright 2013 The MathWorks, Inc.

function test_this
