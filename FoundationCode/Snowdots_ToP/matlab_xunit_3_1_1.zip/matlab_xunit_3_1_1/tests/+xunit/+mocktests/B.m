% Class B is not a TestCase subclass.

% Copyright 2013 The MathWorks, Inc.

classdef B
end
