function test_suite = test_a_bit

% Copyright 2013 The MathWorks, Inc.

initTestSuite

function test_now

function test_later
