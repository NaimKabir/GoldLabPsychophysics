% helper_that is not a test file.

function y = helper_that(x)
y = x;

% Copyright 2013 The MathWorks, Inc.
