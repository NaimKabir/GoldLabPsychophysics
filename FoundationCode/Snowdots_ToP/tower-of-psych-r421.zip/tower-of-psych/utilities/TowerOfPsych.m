function TowerOfPsych
% Placeholder to indicate that Tower of Psych is on the Matlab path.