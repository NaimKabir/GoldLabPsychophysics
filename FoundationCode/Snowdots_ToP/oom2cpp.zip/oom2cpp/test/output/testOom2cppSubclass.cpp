class testOom2cppSubclass : public testOom2cppClass, public someOtherClass
{
    
public:
        Property prop3;
    
    
public:
        Event EventThree;
    
    
public:
self testOom2cppSubclass ()
{
            self. self@testOom2cppClass;
        
}

    
};
