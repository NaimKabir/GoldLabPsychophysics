function SnowDots
% Placeholder to indicate that Snow Dots is on the Matlab path.